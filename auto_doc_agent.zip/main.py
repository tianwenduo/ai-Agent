import openai
from config import OPENAI_API_KEY

openai.api_key = OPENAI_API_KEY

# 示例输入
project_info = {
    "project_name": "智能文档生成 Agent",
    "background": "公司内部文档零散、格式不统一，整理耗时长",
    "pain_points": "团队成员频繁手动整理文档，信息滞后，复用率低",
    "value": "节省 70% 文档整理时间，提高团队协作效率"
}

def generate_document(info):
    prompt = f"""
根据以下信息生成标准化文档内容，语言简明专业，适合内部技术分享：
项目名称: {info['project_name']}
背景: {info['background']}
核心问题: {info['pain_points']}
预期价值: {info['value']}
生成文档内容:
"""
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    return response.choices[0].message.content

if __name__ == "__main__":
    doc_content = generate_document(project_info)
    # 写入 Markdown 文件
    with open("generated_doc.md", "w", encoding="utf-8") as f:
        f.write(doc_content)
    print("文档已生成：generated_doc.md")
