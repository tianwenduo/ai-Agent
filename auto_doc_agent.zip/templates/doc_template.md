# 项目名称: {{project_name}}

## 背景
{{background}}

## 核心问题
{{pain_points}}

## 自动化文档生成结果
{{generated_content}}

## 预期价值
{{value}}
